<table border="0" cellpadding="0" cellspacing="0" width="100%">
    <tbody>
        <tr>
            <td align="center" style="background-color:#eeeeee" bgcolor="#eeeeee">

                <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px">
                    <tbody>
                        <tr>
                            <td align="center" valign="top" style="font-size:0;padding:35px" bgcolor="#F44336">

                                <div style="display:inline-block;max-width:50%;min-width:100px;vertical-align:top;width:100%">
                                    <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:300px">
                                        <tbody>
                                            <tr>
                                                <td align="left" valign="top" style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:36px;font-weight:800;line-height:48px" class="m_8655248040583013820mobile-center">
                                                    <h1 style="font-size:36px;font-weight:800;margin:0;color:#ffffff">ISMART</h1>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                                <div style="display:inline-block;max-width:50%;min-width:100px;vertical-align:top;width:100%" class="m_8655248040583013820mobile-hide">
                                    <table align="left" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:300px">
                                        <tbody>
                                            <tr>
                                                <td align="right" valign="top" style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:48px;font-weight:400;line-height:48px">
                                                    <table cellspacing="0" cellpadding="0" border="0" align="right">
                                                        <tbody>
                                                            <tr>
                                                                <td style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:18px;font-weight:400">
                                                                    <p style="font-size:18px;font-weight:400;margin:0;color:#ffffff"><a href="#m_8655248040583013820_" style="color:#ffffff;text-decoration:none">Shop &nbsp;</a></p>
                                                                </td>
                                                                <td style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:18px;font-weight:400;line-height:24px">
                                                                    <a href="#m_8655248040583013820_" style="color:#ffffff;text-decoration:none"><img src="https://ci3.googleusercontent.com/proxy/COSIChq6NTiDndFnKXdLS7z75QqkAR6uT-1mSkjhmhaIJgc15OIeGs3IXSGFvwSvjl6mB1ojb414yfsCvz-ZYTCnce44guPwln2dyQ=s0-d-e1-ft#https://img.icons8.com/color/48/000000/small-business.png" width="27" height="23" style="display:block;border:0px" class="CToWUd" data-bit="iit"></a>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                            </td>
                        </tr>
                        <tr>
                            <td align="center" style="padding:35px 35px 20px 35px;background-color:#ffffff" bgcolor="#ffffff">
                                <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px">
                                    <tbody>
                                        <tr>
                                            <td align="center" style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;">
                                                <img src="https://ci4.googleusercontent.com/proxy/Xugnh0xeMz7GHl0KhIY6cQG5XE2k38zTmIAJ1kQsIbuizZfpoTuyFGvdVW4SYXPUcymn7edZ1oFjpjD52-0_s1Lb2moEE0rKZ6Cl0CNZIZ35DkxuSA=s0-d-e1-ft#https://img.icons8.com/carbon-copy/100/000000/checked-checkbox.png" width="125" height="120" style="display:block;border:0px" class="CToWUd" data-bit="iit"><br>
                                                <h2 style="font-size:30px;font-weight:800;line-height:36px;color:#333333;margin:0">
                                                    Đặt hàng thành công!
                                                </h2>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;padding-top:10px">
                                                <p style="font-size:16px;font-weight:400;line-height:24px;color:#777777">
                                                    Chúng tôi đang chuẩn bị hàng để bàn giao cho đơn vị vận chuyển
                                                </p>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td align="left" style="padding-top:20px">
                                                <h2 style="color: #0ac5b9;">Thông khách hàng</h2>
                                                <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td width="75%" align="left" bgcolor="#eeeeee" style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:16px;font-weight:800;line-height:24px;padding:10px">
                                                                Tên khách hàng
                                                            </td>
                                                            <td width="25%" align="left" bgcolor="#eeeeee" style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:16px;font-weight:800;line-height:24px;padding:10px">
                                                                Địa chỉ
                                                            </td>
                                                            <td width="25%" align="left" bgcolor="#eeeeee" style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:16px;font-weight:800;line-height:24px;padding:10px">
                                                                Email
                                                            </td>
                                                            <td width="25%" align="left" bgcolor="#eeeeee" style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:16px;font-weight:800;line-height:24px;padding:10px">
                                                                Số điện thoại
                                                            </td>
                                                        </tr>

                                                        <tr>
                                                            <td width="75%" align="left" style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;padding:15px 10px 5px 10px">
                                                                {{$firstOrder->User->name}}
                                                            </td>
                                                            <td width="25%" align="left" style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;padding:15px 10px 5px 10px">
                                                                {{$firstOrder->address}}
                                                            </td>
                                                            <td width="25%" align="left" style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;padding:15px 10px 5px 10px">
                                                                {{$firstOrder->User->email}}
                                                            </td>
                                                            <td width="25%" align="left" style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;padding:15px 10px 5px 10px">
                                                                {{$firstOrder->phone}}
                                                            </td>
                                                        </tr>

                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td align="left" style="padding-top:20px">
                                                <h2 style="color: #0ac5b9;">Thông tin đơn hàng</h2>
                                                <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td width="75%" align="left" bgcolor="#eeeeee" style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:16px;font-weight:800;line-height:24px;padding:10px">
                                                                Tên sản phẩm
                                                            </td>
                                                            <td width="25%" align="left" bgcolor="#eeeeee" style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:16px;font-weight:800;line-height:24px;padding:10px">
                                                                Giá
                                                            </td>
                                                            <td width="25%" align="left" bgcolor="#eeeeee" style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:16px;font-weight:800;line-height:24px;padding:10px">
                                                                Số lượng
                                                            </td>
                                                            <td width="25%" align="left" bgcolor="#eeeeee" style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:16px;font-weight:800;line-height:24px;padding:10px">
                                                                Thành tiền
                                                            </td>
                                                        </tr>
                                                        @foreach($order_detail as $item)
                                                        <tr>
                                                            <td width="75%" align="left" style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;padding:15px 10px 5px 10px">
                                                                {{$item->product->name}}
                                                            </td>
                                                            <td width="25%" align="left" style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;padding:15px 10px 5px 10px">
                                                                {{number_format($item->price,0,',','.')}}đ
                                                            </td>
                                                            <td width="25%" align="left" style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:24px;padding:15px 10px 5px 10px">
                                                                {{$item->quantity}}
                                                            </td>
                                                            <td width="25%" align="left">
                                                                {{number_format($item->price * $item->quantity,0,',','.')}}đ
                                                            </td>
                                                        </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left" style="padding-top:20px">
                                                <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td width="75%" align="left" style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:16px;font-weight:800;line-height:24px;padding:10px;border-top:3px solid #eeeeee;border-bottom:3px solid #eeeeee">
                                                                Tổng tiền
                                                            </td>
                                                            <td width="25%" align="left" style="font-family:Open Sans,Helvetica,Arial,sans-serif;font-size:16px;font-weight:800;line-height:24px;padding:10px;border-top:3px solid #eeeeee;border-bottom:3px solid #eeeeee">
                                                                {{number_format($firstOrder->total_price,0,',','.')}}VNĐ
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>

                            </td>
                        </tr>
                    </tbody>
                </table>
                <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px">
                    <tbody>
                        <tr>
                            <td>
                                <div>
                                    <p>Quý khách vui lòng giữ lại hóa đơn, hộp sản phẩm và phiếu bảo hành (nếu có) để đổi
                                        trả hàng hoặc bảo hành khi cần thiết.</p>
                                    <p>Liên hệ Hotline <strong style="color:#099202">0961924960</strong> (8h00-21h00 cả T7,CN).
                                    </p>
                                    <p><strong>ISMART cảm ơn quý khách đã đặt hàng, chúng tôi sẽ không ngừng nổ lực để phục
                                            vụ quý khách tốt hơn!</strong></p>
                                    <div style="height:auto">
                                        <p>
                                            Quý khách nhận được email này vì đã dùng email này đặt hàng tại cửa hàng trực
                                            tuyến ISMART.
                                            <br>
                                            Nếu không phải quý khách đặt hàng vui lòng liên hệ số điện thoại 0961924960
                                            hoặc email <a style="color:#4b8da5">nguyenvannam041001@gmail.com</a> để được tư vấn!
                                        </p>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>